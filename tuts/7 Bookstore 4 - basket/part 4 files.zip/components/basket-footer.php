</table>

<div class='center'>
  <h2>Total price: £<?php echo $totalPrice; ?></h2>
  
  <a class='button' href='checkout.php'>Complete your order</a>
</div>