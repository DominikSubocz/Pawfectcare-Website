const form = document.querySelector("#surveyForm");

/*
  Take an array of form field values and check to 
  see if any are empty or evaluate to false.

  Returns true if all values are present and false
  if any are empty.
*/
function formFieldsAreEmpty(fieldsArray) {
  for (const field of fieldsArray) {
    if (!field) {
      return true;
    }
  }
  return false;
}

// Checks if a given email is in the correct format
function validateEmail(email) {
  const regex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return regex.test(String(email).toLowerCase());
}

// Remove a given number of years from a date
function subtractYears(date, years) {
  date.setFullYear(date.getFullYear() - years);

  return date;
}

// Output error messages to a given DOM element
function outputErrorMessage(errorMsg) {
  const output = document.querySelector("#errorOutput");

  output.innerHTML = errorMsg;
}

// Code from validate.png goes here...