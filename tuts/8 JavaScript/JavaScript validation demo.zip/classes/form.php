<?php

require_once("classes/utils.php");

class Form {
  public static function validate() {
    if (Utils::postValuesAreEmpty(["fullName", "email", "birthDate", "enrollmentYear", "terms"])) {
      return "<p class='error'>ERROR: One or more inputs are empty</p>";
    }

    $error = "";

    $fullName = $_POST["fullName"];
    $email = $_POST["email"];
    $birthDate = $_POST["birthDate"];
    $enrollmentYear = $_POST["enrollmentYear"];

    // Validate full name
    if (strlen($fullName) < 4 || strlen($fullName) > 64) {
      $error .= "<p class='error'>ERROR: Full name must be between 4 and 64 characters</p>";
    }

    // Validate email address
    $email = filter_var($email, FILTER_VALIDATE_EMAIL);

    // Invalid email address
    if (!$email) {
      $error .= "<p class='error'>ERROR: Email address is invalid</p>";
    }

    // Validate birth date
    if (!Utils::isValidDate($birthDate)) {
      $error .= "<p class='error'>ERROR: Birth date is invalid</p>";
    }

    // Only accept responses from those of 16 years or older
    $validBirthDate = date("Y-m-d", strtotime("-16 years"));

    if ($birthDate > $validBirthDate) {
      $error .= "<p class='error'>ERROR: You must be at least 16 years of age to submit this form</p>";
    }

    // Validate enrollment year
    $enrollmentYear = filter_var($enrollmentYear, FILTER_VALIDATE_INT);

    // Get the current year as an integer
    $currentYear = (int) date("Y");

    // Invalid email address
    if (!$enrollmentYear) {
      $error .= "<p class='error'>ERROR: Enrollment year is invalid</p>";
    } else if ($enrollmentYear > $currentYear) {
      $error .= "<p class='error'>ERROR: Enrollment year must be no later than $currentYear</p>";
    }

    return $error;
  }
}