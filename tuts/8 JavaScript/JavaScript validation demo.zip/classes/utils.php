<?php

class Utils {
  public static $projectFilePath = "http://localhost/jsform";

  /**
   * Takes an array of $_POST[] keys and checks if any 
   * are empty.
   *
   * Returns true if any values are missing.
   */
  public static function postValuesAreEmpty($arrayOfKeys) {
    foreach ($arrayOfKeys as $key) {
      if (empty($_POST[$key])) {
        return true;
      }
    }
    return false;
  }

  /**
   * Escape input string to prevent accidental evaluation of HTML 
   * or JavaScript
   */
  public static function escape($input) {
    return trim(htmlspecialchars($input));
  }

  // Get the file extension of a given file
  public static function getFileExtension($filename) {
    $parts = explode(".", $filename);
    // end() must receive a variable
    return end($parts);
  }

  /*
    Checks if the given string is a valid date using PHP. 
    It uses PHP's DateTime class to validate the date according 
    to the specified format.
    
    This function returns true if the date is valid, otherwise 
    false.
  */
  function isValidDate($date, $format = 'Y-m-d'){
    $dt = DateTime::createFromFormat($format, $date);
    return $dt && $dt->format($format) === $date;
  }
}