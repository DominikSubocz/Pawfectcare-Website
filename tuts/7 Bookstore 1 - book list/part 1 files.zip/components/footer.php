  </main>

  <footer class="page-footer">
    <p>Copyright &copy;<?php echo date("Y"); ?></p>
  </footer>
</body>
</html>