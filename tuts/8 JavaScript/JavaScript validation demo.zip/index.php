<?php

require("classes/utils.php");

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  require("classes/form.php");

  $error = Form::validate();

  if (!$error) {
    header("Location: " . Utils::$projectFilePath . "/success.php");
  }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>JS validation demo</title>
  <link rel="stylesheet" href="style.css">
  <script src="js/validate.js" defer></script>
</head>
<body>
  <div class="page-wrapper">
    <h1>Enrollment Year Survey</h1>
  
    <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>" id="surveyForm">
      <label>Full Name*</label>
      <input type="text" name="fullName">
  
      <label>Email Address*</label>
      <input type="email" name="email">
  
      <label>Date of Birth*</label>
      <input type="date" name="birthDate">
  
      <label>Year of Enrollment*</label>
      <input type="number" name="enrollmentYear">
  
      <label>
        <input class="checkbox" type="checkbox" name="terms">
         - I agree with the terms and conditions*
        </label>

      <br>
  
      <label>
        <input class="checkbox" type="checkbox" name="optIn">
         - Opt-in to additional marketing communications
        </label>
      
      <input class="btn" type="submit" value="Submit form">

      <p>
        * &mdash; Required fields
      </p>
  
      <div id="errorOutput">
        <?php echo $error; ?>
      </div>
    </form>
  </div>
</body>
</html>